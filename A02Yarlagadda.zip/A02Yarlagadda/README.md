My name is Phani Lakshman Yarlagadda 
This project is for calculating your respective semester percentage
we enter the total points & marks scored for each exam module.
now the java script and jquery is also added to the project.
