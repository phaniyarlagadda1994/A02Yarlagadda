
var a=0;
var b=0;
var c=0;
var d=0;
var e=0;
var f=0;
var g=0;
var h=0;
var i=0;
var j=0;
var k=0;
var l=0;
var m=0;
var n=0;
var o=0;
var p=0;
var q=0;

/*function sum1(){
  a=$("#first").val();
  b=$("#third").val();
  c=$("#fifth").val();
  d=$("#seven").val();
  e=$("#nine").val();
  f=$("#eleven").val();
  g=$("#thirteen").val();
  h=Number(a)+Number(b)+Number(c)+Number(d)+Number(e)+Number(f)+Number(g);
  $("#fifteen").val()=h;
  i=$("#second").val();
  j=$("#fourth").val();
  k=$("#sixth").val();
  l=$("#eight").val();
  m=$("#ten").val();
  n=$("#twelve").val();
  o=$("#fourteen").val();
  p=Number(i)+Number(j)+Number(k)+Number(l)+Number(m)+Number(n)+Number(o);
  $("#sixteen").val()=p;
  q=(h/p)*100;
  $("#seventeen").val()=q;
}
*/
function sum2(){
  a=$("#a1").val();
  b=$("#a3").val();
  c=$("#a5").val();
  d=$("#a7").val();
  e=$("#a9").val();
  f=$("#a11").val();
  g=$("#a13").val();
  h=Number(a)+Number(b)+Number(c)+Number(d)+Number(e)+Number(f)+Number(g);
  $("#a15").val(h);
  i=$("#a2").val();
  j=$("#a4").val();
  k=$("#a6").val();
  l=$("#a8").val();
  m=$("#a10").val();
  n=$("#a12").val();
  o=$("#a14").val();
  p=Number(i)+Number(j)+Number(k)+Number(l)+Number(m)+Number(n)+Number(o);
  $("#a16").val(p);
  q=(h/p)*100;
  $("#a17").val(q);
}

function sum3(){
  a=$("#w1").val();
  b=$("#w3").val();
  c=$("#w5").val();
  d=$("#w7").val();
  e=$("#w9").val();
  f=$("#w11").val();
  g=$("#w13").val();
  h=Number(a)+Number(b)+Number(c)+Number(d)+Number(e)+Number(f)+Number(g);
  $("#w15").val(h);
  i=$("#w2").val();
  j=$("#w4").val();
  k=$("#w6").val();
  l=$("#w8").val();
  m=$("#w10").val();
  n=$("#w12").val();
  o=$("#w14").val();
  p=Number(i)+Number(j)+Number(k)+Number(l)+Number(m)+Number(n)+Number(o);
  $("#w16").val(p);
  q=(h/p)*100;
  $("#w17").val(q);
}
/*
function sum1(){
  a=document.getElementById("first").value;
  b=document.getElementById("third").value;
  c=document.getElementById("fifth").value;
  d=document.getElementById("seven").value;
  e=document.getElementById("nine").value;
  f=document.getElementById("eleven").value;
  g=document.getElementById("thirteen").value;
  h=Number(a)+Number(b)+Number(c)+Number(d)+Number(e)+Number(f)+Number(g);
  document.getElementById("fifteen").value=h;
  i=document.getElementById("second").value;
  j=document.getElementById("fourth").value;
  k=document.getElementById("sixth").value;
  l=document.getElementById("eight").value;
  m=document.getElementById("ten").value;
  n=document.getElementById("twelve").value;
  o=document.getElementById("fourteen").value;
  p=Number(i)+Number(j)+Number(k)+Number(l)+Number(m)+Number(n)+Number(o);
  p=add(Number(i),add(Number(j),add(Number(k),add.(Number(l),add(Number(m),add(Number(n),Number(o)))))));
  document.getElementById("sixteen").value=p;
  q=(h/p)*100;
  document.getElementById("seventeen").value=q;
}
*/

function add(a,b){
  if (typeof a !== 'number' || typeof b !== 'number') {
        throw Error("only numbers are allowed");
    }
    else{
        return a+b;
    } 
} 